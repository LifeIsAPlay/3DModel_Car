import { Canvas } from "@react-three/fiber";
import { useGLTF, Stage, PresentationControls, Stats } from "@react-three/drei";

function Model(props) {
  const { scene } = useGLTF("/lambo.glb");
  return <primitive object={scene} {...props} />;
}

function App() {
  return (
    <Canvas dpr={[1, 2]} camera={{ fov: 45 }} style={{ position: "absolute" }}>
      <color attach="background" args={["#101010"]} />
      <PresentationControls speed={1.5} global zoom={0.5} azimuthal={[-Infinity, Infinity]} polar={[-Infinity, Infinity]}>
        <Stage environment={null}>
          <spotLight position={[10, 10, 10]} angle={0.3} penumbra={1} intensity={0.5} castShadow />
          <spotLight position={[-10, -10, -10]} angle={0.3} penumbra={1} intensity={0.5} castShadow />
          <Model scale={0.01} />
        </Stage>
      </PresentationControls>
      <Stats />
    </Canvas>
  );
}

export default App;

